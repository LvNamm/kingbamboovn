<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CategoryCtrl extends Controller
{
    public function index(){
        return view("index");
    }

    public function showProductByCategory($category){
        $categorys  =  [
            'all'=>"Tất cả sản phẩm",
            'trang-tri-nha-cua'=>"Trang trí nhà cửa",
            'trang-tri-quan-cafe' => "Trang trí quán cafe",
            'trang-tri-van-phong' => "Trang trí văn phòng",
            'khay-dung' => "Khay đựng",
            'nha-bep' => "Nhà bếp",
            'tui-xach' => "Khay đựng",
            'gio-dung' => "Giỏ đựng"
        ];
        return view("list-products-of-category",["category"=>$categorys[$category]]);
    }
}
