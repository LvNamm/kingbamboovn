<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProductCtrl extends Controller
{
    public function show($product){
        return view("product");
    }
}
